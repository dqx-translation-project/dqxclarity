﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace JSON_conv
{
    public abstract class Json_File_Object
    {
        public Dictionary<string, string> stringPairs { get; set; }
        public bool isValid { get; set; }
        public Json_File_Object()
        {
            isValid = true;
        }
        public string GetValue(string key)
        {
            if (stringPairs.ContainsKey(key))
                return stringPairs[key];
            return String.Empty;
        }
    }
    public class Json_File_1_0 : Json_File_Object
    {
        /* Old flat format: <jp,eng>
        Example:
        {
            "戦士": "WAR",
            "僧侶": "PRI",
            "魔使": "MGE",
        }
         */
        public void DeserializeJSON(string inputFile)
        {
            using (StreamReader r = new StreamReader(inputFile))
            {
                string json = r.ReadToEnd();
                stringPairs = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
            }
            isValid = true;
        }
        public void SerializeJSON(string outputFile)
        {
            using (StreamWriter w = new StreamWriter(outputFile))
            {
                string jsonFile = Newtonsoft.Json.JsonConvert.SerializeObject(stringPairs, Formatting.Indented);
                w.Write(jsonFile);
            }
        }
    }

    public class Json_File_2_0 : Json_File_Object
    {
        /* New nested format: <idx, <jp,eng>>
        Example:
        {
          "1": {
            "エルフ": ""
          },
          "2": {
            "ウェディ": ""
          },
          "3": {
            "clarity_nt_char_1": "clarity_nt_char_1"
          },
        }
         */
        public Dictionary<string, Dictionary<string, string>> data { get; set; }

        public void DeserializeJSON(string inputFile)
        {
            using (StreamReader r = new StreamReader(inputFile))
            {
                string json = r.ReadToEnd();
                data = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, string>>>(json);
            }
            // build jpn/eng string pair dictionnary
            stringPairs = new Dictionary<string, string>();
            foreach (var key in data.Keys)
            {
                // Look for an existing translation in the old json file
                var item = data[key];
                var itemKey = item.Keys.First();
                var itemVal = item.Values.First();
                if (stringPairs.ContainsKey(item.Keys.First()) && !stringPairs[itemKey].Equals(itemVal))
                {
                    // warning
                    Console.WriteLine("Warning: duplicate entry in source json\n Src key: {0}\n Current value: {1}\n New value: {2}\n", key, stringPairs[itemKey], itemVal);
                }
                stringPairs[itemKey] = itemVal;
            }
            isValid = true;
        }
        public void SerializeJSON(string outputFile, Json_File_Object jsonSrc)
        {
            using (StreamWriter w = new StreamWriter(outputFile))
            {
                string jsonFile = Newtonsoft.Json.JsonConvert.SerializeObject(data, Formatting.Indented, new Json20Converter(jsonSrc, typeof(Dictionary<string, string>)));
                w.Write(jsonFile);
            }
        }
    }
}