﻿using System;
using System.IO;
using System.Linq;
using Microsoft.Extensions.CommandLineUtils;

namespace JSON_conv
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var cmd = new CommandLineApplication();
            var argSrc  = cmd.Option("-s | --src <value>", "input JSON file, nested/flat json, translated" , CommandOptionType.SingleValue);
            var argDst  = cmd.Option("-d | --dst <value>", "input JSON file, nested json, untranslated"    , CommandOptionType.SingleValue);
            var argOut  = cmd.Option("-o | --out <value>", "output JSON file, nested, translated"          , CommandOptionType.SingleValue);

            cmd.OnExecute(() =>
            {
                // Command line error handling
                if( argSrc.Values.Count() == 0 ||
                    argDst.Values.Count() == 0 ||
                    argOut.Values.Count()   == 0)
                {
                    Console.WriteLine("Wrong arguments, use -h | --help to display options.");
                    return 1;
                }
                if(!File.Exists(argSrc.Value()))
                {
                    Console.WriteLine("Input file {0} doesn't exist.", argSrc.Value());
                    return 1;
                }
                if (!File.Exists(argDst.Value()))
                {
                    Console.WriteLine("Input file {0} doesn't exist.", argDst.Value());
                    return 1;
                }

                // Deserialize json 1.0 (old)
                Json_File_1_0 jsonSrc1 = new Json_File_1_0();
                Json_File_2_0 jsonSrc2 = new Json_File_2_0();
                try { jsonSrc1.DeserializeJSON(argSrc.Value()); } catch { jsonSrc1.isValid = false; }
                try { jsonSrc2.DeserializeJSON(argSrc.Value()); } catch { jsonSrc2.isValid = false; }

                // Deserialize json 2.0 (new)
                Json_File_2_0 jsonDst = new Json_File_2_0();
                try
                {
                    jsonDst.DeserializeJSON(argDst.Value());
                }
                catch
                {
                    Console.WriteLine("Error: cannot read input JSON file {0}.", argDst.Value());
                    return 1;
                }

                // Serialize json 2.0 (new, nested)
                if (jsonSrc1.isValid)
                {
                    jsonDst.SerializeJSON(argOut.Value(), jsonSrc1);
                }
                else
                if (jsonSrc2.isValid)
                {
                    jsonDst.SerializeJSON(argOut.Value(), jsonSrc2);
                }
                else
                {
                    Console.WriteLine("Error: cannot read input JSON file {0}.", argSrc.Value());
                    return 1;
                }
                return 0;
            });

            cmd.HelpOption("-? | -h | --help");
            cmd.Execute(args);
        }
    }
}