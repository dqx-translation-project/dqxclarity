using System;
using System.Linq;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace JSON_conv
{
    public class Json20Converter : JsonConverter
    {
        private readonly Type[] _types;
        private readonly Json_File_Object _jsonSrc;

        public Json20Converter(Json_File_Object jsonSrc, params Type[] types)
        {
            _types = types;
            _jsonSrc = jsonSrc;
        }

        // The only purpose this custom writer is to override values by existing translations from _jsonSrc,
        // otherwise the serialization is identical to the default one.
        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            JToken t = JToken.FromObject(value);

            if (t.Type != JTokenType.Object)
            {
                t.WriteTo(writer);
            }
            else
            {
                JObject o = (JObject)t;
                var target = new Dictionary<string, string>(o.ToObject<Dictionary<string, string>>());
                foreach (var key in target.Keys)
                {
                    // Look for an existing translation in the old json file
                    string val = _jsonSrc.GetValue(key);
                    if (val != String.Empty)
                        target[key] = val;
                }
                o = JObject.FromObject(target);
                o.WriteTo(writer);
            }
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            throw new NotImplementedException("Not implemented. Can just use default reader");
        }

        public override bool CanRead
        {
            get { return false; }
        }

        public override bool CanConvert(Type objectType)
        {
            return _types.Any(t => t == objectType);
        }
    }
}